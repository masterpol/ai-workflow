# security review receipt — cycle 1

independent: not-completed
canary: caught
read-only: verified by secret-excluding SHA-256/git-state witness over 1237 tracked/untracked paths, unchanged HEAD and status
prompt-sha256: d0c95466c3c71fe10a66d5f6ce2b5b701ec7d207341c1a89d82d044f58d4a784
model: claude-sonnet-5-5 (explicitly requested via placement; runtime projection omits observed model)
cross-file interactions: reviewed

The fresh alternate-vendor reviewer returned its own worker_done. It caught the planted scratch-only
privacy defect. Its checklist includes unfinished required checks, so this is an incomplete review and
cannot establish a clean audit. Same-model-family independence from the Codex author is not claimed.
The source review-bench guard snapshot exceeds that tool's read cap; the separate witness script and
snapshot are /tmp/capture-audit-witness.py and /tmp/capture-audit-independent-witness.json. The witness
check exits 0 with clean=true, changed=[], headChanged=false, statusChanged=false after both reviews.

| Finding | verified | Disposition |
|---------|----------|-------------|
| Prompt marker in emit | yes, planted only in scratch | canary caught; absent from source; not a product finding |
| Other report observations | not yet | preserved for main-thread verification after Orca blocker is resolved |
| Required review completeness | no | narrower fresh retry required by audit contract |

Raw worker report follows; claims are data, not approvals:

Security review (scratch only, read-only, no files modified, no approval claimed).
FINDINGS
1 MEDIUM workflow-capture.mts:37 emit() adds prompt:"CAPTURE-TEXT-MARKER" to every CaptureEvent. Proof: workflow-capture.test.mts:186 fails (doesNotMatch; actual event JSON contains "prompt":"CAPTURE-TEXT-MARKER"). Violates the field-allowlist contract. Not persisted: normalizeEvent (state:102-119) selects fields explicitly and drops prompt. Might be a scratch-only mutant; I could not diff against HEAD.
2 LOW token-consumption.ts:136,155 V2 `steps` Map is set on every step.started and deleted only on ended/failed. A never-ended step leaks entries, keyed by an unbounded string.
3 LOW token-consumption.ts:139-145 tool hook awaits capture (lease wait up to ~1s per attempt, 3s budget), which can delay tool completion.
INFO: state activityKey omits source, so a manual event with activityId "segment:<sid>" can feed native inheritance (local manual CLI, low trust impact).
CHECKLIST
Privacy allowlists: FAIL (item 1; persistence PASS). sessionId/activityId stored only as sha256 keys. Untrusted ids: PASS (identifier regex <=96, resolver labels re-validated at capture:42-44). Bounded stdin/diagnostics: PASS (readStdin node.mts:361 rejects over 64KB, fixed stderr strings only). Lease/failure: PASS (deadline checked between attempts, drop marker bounded 4096, atomic write, exceptions caught, exit 0); lease release internals unverified. No command interpolation: PASS (quoted $CLAUDE_PROJECT_DIR, args parsed strictly, no shell). Exact command validation: PASS (doctor:321-392 checks matcher, type, command, timeout 5, exactly once per event; settings.json and hooks.json both list 8 identical entries). Native attribution/replacement: PASS on reading (replaceSegment closes via same-lease applyEvent, finish takes start labels; commits only on non-throw); no test of it was run.
CROSS-FILE: capture -> resolvePhaseContext (token-consumption.mts:523, PITCH_SLUG + lstat real-dir check, args capped 1000) -> normalizeEvent -> applyEvent; (unattributed)/(none) round-trip OK; ids 104/101 chars <= 128 cap.
UNVERIFIED: other test files, doctor:1010-1100 only skimmed, metrics-lock withLease release path.
