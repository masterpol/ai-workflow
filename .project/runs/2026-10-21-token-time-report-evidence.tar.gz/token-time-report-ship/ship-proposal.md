# token-time-report ship preparation

Audit-end approval received: owner “Approve”, 2026-10-21. Ship startup is ready. No worker changes remain unintegrated; completed shared-checkout work was independently verified. One earlier resource remains human-owned; no cleanup is requested.

## Blocker

The mandatory wrapper exits 1: `No package.json or Muro document verifier found. Define project checks before shipping.` This bundle intentionally has no application package manifest; stack.md defines direct commands. The wrapper is the existing backlog issue, not a new regression. At the audit cycle cap, no waiver is inferred. Await explicit approval to substitute the documented direct verification gauntlet, then prepare the final ship/hold gate.

## Concrete fallback

- Full Node: `node ai-framework/scripts/run-tests.mts --runtime node`.
- Scoped Bun: `node ai-framework/scripts/run-tests.mts --runtime bun` with the three flow tests, review-bench, state-html and state-snapshot tests.
- `node ai-framework/scripts/workflow-doctor.mts` (exit 0; existing state-graph.test.mts runtime-boundary warning).
- `node ai-framework/scripts/setup-validator.mts`.
- `node ai-framework/scripts/graphify.mts --check`.
- Scoped source diff, secret-path and debug checks; `git diff --check`.
- Build/typecheck/lint/i18n are N/A: stack.md declares no such commands. No temporary package.json or Muro verifier will be fabricated.

## Prepared release and closeout

Release proposal: v2.41.0, Added. Exact draft entry and files are in release-proposal.md/json. Deterministic changelog helpers project 10 release lines, bringing the pitch from 1479 to 1489 lines across 13 files, under 1500/15. VERSION and CHANGELOG remain unchanged.

Reconcile all three scopes; retain OS check-to-syscall races, non-atomic three-file publication and named trusted-root/static-UI follow-ups. Archive log/hill and bounded allowlisted verification/dispatch evidence, preserving historical records. Prepare SHIPPED.md and a compact status change for the final ship/hold gate. No commit, push or public publication is proposed.

Knowledge proposal: resolve the two existing guard issues (snapshot cap and secret-file hashing); promote the history projection and staging cleanup incidents as two new linked issues; add one low-confidence exact-identity/window-aware metrics-join pattern. Record recurrence in reviewer-measurement, wrong-reason mutant, stalled-write and publish-reinspection entries. Rebuild the generated graph/index after applying approved closeout changes. Flag reviewer packet completeness and mutation quality for cooldown, without changing rules.

Append four TTR-A1–A4 follow-ups (trusted Git execution, strict count parsing, dot-prefix/raw-error tooling polish, optional static-report usability). Retain existing wrapper/timing backlog ownership; append resolutions for the two guard items rather than deleting their history.

Final ship/hold confirmation remains required after this fallback is accepted and the prepared closeout is reviewable.
