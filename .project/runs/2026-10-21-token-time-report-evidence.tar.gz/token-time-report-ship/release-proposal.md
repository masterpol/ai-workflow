## [2.41.0] - 2026-10-22
### Added
- Add a joined token and workflow-time report with guarded publication
- Preview JSON, Markdown or inert HTML by exact pitch/phase/scope, preserving token coverage, stored union timing, unavailable history and capture status.
- Publish only owned fixed report files with generation IDs; link existing HTML from state and harden review snapshots for size and secret exclusion.

Files: ai-framework/scripts/flow-join.mts, ai-framework/scripts/flow-join.test.mts, ai-framework/scripts/flow-render.mts, ai-framework/scripts/flow-render.test.mts, ai-framework/scripts/flow-report.mts, ai-framework/scripts/flow-report.test.mts, ai-framework/scripts/state-pages.mts, ai-framework/scripts/state-html.test.mts, ai-framework/scripts/review-bench.mts, ai-framework/scripts/review-bench.test.mts, ai-framework/integrations/workflow-metrics.md
