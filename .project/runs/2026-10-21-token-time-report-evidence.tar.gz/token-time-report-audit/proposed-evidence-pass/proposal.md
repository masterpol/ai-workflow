# Proposed final evidence pass: token-time-report

Prepared in response to the owner's “Approve”. No worker has been launched and no additional retry has been spent. Shipping remains gated by completed independent evidence.

The audit skill permits one fresh retry for incomplete reviews; that retry has been used. This proposal requires an explicit revision allowing one additional bounded evidence pass. It does not waive any missing checks or authorize source changes.

Four fresh standard-model Orca reviewers receive separate scratch copies. The approved plan and metrics contract will be supplied as visible root files (REVIEW-CONTRACT.md) as well as concise inline instructions, avoiding the prior false claims that hidden contract files were absent. Each reviewer receives only the unfinished checks listed below. Commands are limited to 20 seconds and each reviewer to 18 tool calls. Original files remain guarded; scratch canaries and their detection are required. Full-suite author checks remain labelled author-run.

## code

- Read the approved plan and workflow-metrics contract, supplied as visible root files in the scratch packet; verify S1-S3 contract conformance already tested by the selected suite.
- Trace FlowReport.notes to fixed bundle constants; assess the documented cohesive-unit rationale against coding-standards and boundaries.
- Review final review-bench secret-exclusion patch and no-read regression, plus snapshot cap writer/reader agreement.

## security

- Read withLease and its metrics-lock helpers: independently verify that preview lease acquisition creates no project files/directories and releases resources on refusal.
- Read runWorkflowSync and runtime child adapter: establish which environment and commands execute in the selected test/review paths.
- Review final guard secret exclusion before any filesystem read, retaining symlink/FIFO refusals and bounded snapshot input/output.

## coverage

- Measure report-module coverage independently against utility >=90% and CLI >=80% line targets.
- Verify source/output bounds and short-write refusal with focused scratch mutants; classify any surviving redundant guard explicitly.
- Run the state snapshot/link regression files and final 35-case guard suite, split into commands under 20 seconds.
- Map final secret-exclusion and snapshot-cap guards to tests that fail when removed.

## ux

- Read component-architecture guidance applicable to a pure static renderer; justify framework-only N/A items.
- Independently execute focused proofs of three provisional warnings, inert Markdown URL/email labels and semantic table/keyboard attributes.
- Review the fixed state link against the renderer filename and source-status model; browser geometry/contrast remain explicitly outside the approved static review.

No further automatic retry is proposed. If required evidence remains incomplete, preserve it and return the unresolved checks without shipping. VERSION and CHANGELOG stay untouched during review.
