# Plan: token-time-report

**Pitch**: pitch.md • **Appetite**: big-batch • **Hill**: hill.md
**Status**: approved by owner, 2026-10-21 (“Approve”); impact acknowledged. Build start approved by owner on 2026-10-21 (“Approve”).
**Budget**: 6 new + 5 modified files; about 1,300 changed lines including tests/docs/release, hard cap 15 files / 1,500 LOC / one week. Estimates are not implementation measurements.

## Scopes

Paths below are relative to `ai-framework/scripts/` unless stated otherwise. Release metadata belongs to ship, not an early version bump.

| ID | Name | Files | LOC est | Depends on | Parallel with | Subagent? | Dispatch model |
|----|------|-------|---------|------------|---------------|-----------|----------------|
| S1 | Read-only joined JSON report | new flow-join.mts, flow-join.test.mts, flow-report.mts, flow-report.test.mts | 700 | — | — | yes; self-contained JSON CLI, four owned files and explicit tests | standard; configured Claude Sonnet |
| S2 | Markdown/HTML and owned publication | new flow-render.mts, flow-render.test.mts; extend flow-report.mts and its test | 500 | S1 | — | yes; sequential ownership transfer after S1 settles | standard; configured Claude Sonnet |
| S3 | State link and portable contract | modify state-pages.mts, state-html.test.mts, ../integrations/workflow-metrics.md; VERSION/CHANGELOG.md at ship | 96 | S2 | — | no; coordinator handles small integration and release serialization | — |

Each scope leaves a usable result: S1 previews joined JSON, S2 exports three formats, S3 exposes the existing report from /state and documents the contract. S1's temporary JSON-only delivery is an implementation slice, not a reduction of the approved final scope.

## Interfaces and decisions pinned before build

- `flow-join.mts` owns minimal typed source/report interfaces, projection validation and pure joining. Treat all disk values as unknown until validated. It imports no filesystem or CLI code. Renderer consumes only the sanitized report model. CLI imports joiner/renderer and RuntimeDeps; no reverse imports.
- CLI: `node ai-framework/scripts/flow-report.mts --root <project> [--format json|markdown|html | --apply]`. Default format JSON; no apply means stdout preview only. Apply publishes all three fixed report names and prints a publication summary; --format and --apply are mutually exclusive. No arbitrary destination or shell command argument. Unknown flags exit 2; unsafe path, lease failure or refused publication exits 1. A successfully rendered report with missing/unsupported sources exits 0 and carries unavailable statuses.
- Read token-consumption.json and workflow-usage.json under exactly one `withMetricsLease` acquisition using its guarded dependencies. Reuse exported `metricsDirectory(root,false)`, `readText` and `readWorkflowState` unchanged. Never call recordEvent, recordWorkflowEvent or a writer to read. No metrics directory is created during preview.
- Token projection requires schemaVersion=3, bounded flows, valid timestamps, nonnegative safe numeric counts and reporting-count consistency. Copy only needed fields; reject invalid projection without echoing values. Usage schema 2 uses its existing reader; in-memory v1 compatibility remains legacy/unjoinable and never rewrites the file. Unsupported input is unavailable, not an empty valid source.
- Join keys use exact pitch slug, pipeline phase and scope. Match the resolver's existing grammar (`^[a-z0-9][a-z0-9-]{0,79}$`, the 12 phases in token-consumption.mts, and `S` plus 1–3 digits or `(none)`). No current-directory existence check: moved/shipped pitches retain their identity. Never re-resolve a historical key from a live pointer. `(other)`, `(unknown)`, `(unattributed)` and noncanonical legacy keys remain source-specific unjoinable rows.
- Preserve token-only and timing-only rows. Vendor rows carry tokens, completions, reported and unavailable counts. No reported usage means tokens=null; some usage means a partial sum with coverage. Checked arithmetic refuses an overflowing aggregate. No estimated usage. Label vendor completion units from the existing contract; differing units are not ranked as equivalent work.
- Pitch/phase/scope token rollups may sum disjoint token leaves once. Timing rollups use their stored rows, never sums of children or vendor copies. Use only settled activeMs/waitMs. Show global pending and buffered interval counts; label timing provisional while intervals remain. Do not advance the frontier, extrapolate to now, or mutate/fold state in the report.
- Source metadata includes status, since, updatedAt, fixed reason and coverage/health. More than seven days old is stale. Different observation windows remain explicit; no efficiency ratios. Effort, cache-hit and output/input ratios are unavailable with fixed reasons. Wait is a lower bound of elapsed time between turns, not necessarily think-time.
- Pitch transitions/trace come from usage.pitches, not inference from chat. Preserve transition classes and at most the existing 32 trace entries. Scope/phase failures are not synthesized from pitch-level summary outcomes.
- Optional history reads only `.project/reports/state.json`, outside the metrics lease, with separately pinned project/reports ancestry and guarded read. Validate schema 1, generatedAt, history.items Fact rows and nested availability. Join by exact slug, preserve per-field partial/unavailable states, disclose snapshot age and history limits. A missing slug in a truncated snapshot is unavailable, not zero/not-shipped. Never invoke snapshot generation or parse pitch/audit records.
- Bound source bytes to 4 MiB each, history to 4 MiB; projection traversal to 51 pitch buckets, 16 phases per pitch, 26 scopes per phase and 600 token vendor leaves per source. Over-limit projections are refused. Output keeps at most 100 joined leaf rows plus their displayed ancestors in stable lexical order, with explicit omitted counts. Full validated source totals remain separate from displayed-row totals. Bound each output to 4 MiB; if exceeded, refuse publication with a fixed reason rather than writing a partial file.
- All label-keyed storage uses Map/null-prototype maps. Validate identifiers and scrub credential-shaped values before every format, including JSON metadata and reason text. Never print rejected raw values, internal session IDs, pending identifiers, prompts or transcript contents.

## Exit criteria per scope

Commands listed here are build-time requirements, not checks already run. Tests live beside source and use shared RuntimeDeps helpers. Node is the full-suite authority; Bun covers changed modules as the supported alternate runtime.

### S1 — snapshot and join

`node ai-framework/scripts/run-tests.mts --runtime node ai-framework/scripts/flow-join.test.mts ai-framework/scripts/flow-report.test.mts` exits 0.

Behavior cases must prove:
- Exact three-component match, `(none)` match, every sentinel refused as identity, canonical legacy mismatch, token-only and time-only rows; a pitch folded only in one store remains unmatched with separate overflow totals.
- Partial/unreported tokens, safe-integer overflow, prototype keys, invalid dates/versions, missing/refused/oversized/FIFO/symlink sources, stale history, truncated missing history, unequal observation windows and stable output caps.
- Overlapping child timing is never added into a parent; buffered and pending activity stays provisional without fabricated elapsed time. Duplicate vendor token rows do not duplicate timing.
- One lease acquisition, no nested acquisition, no source writes, no preview filesystem changes, lease release on refusal, legacy lock refusal; directory swap injected during acquisition leaves outside files unchanged. Fake the lease dependencies rather than bind a live port.
- Importing the CLI has no side effect; preview emits parseable sanitized JSON. No `any`-equivalent validators.

### S2 — three formats and publication

`node ai-framework/scripts/run-tests.mts --runtime node ai-framework/scripts/flow-render.test.mts ai-framework/scripts/flow-report.test.mts ai-framework/scripts/flow-join.test.mts` exits 0.

Behavior/artifact checks (the UI build equivalent for this package-less static report):
- All three formats expose the same sanitized report semantics, units and coverage; no untrusted identifiers or credential-shaped fixtures survive any output.
- HTML is standalone, inert, CSP-protected and keyboard-readable, with semantic table captions/headers and scrollable wide tables. No script, external resource or active user-supplied link. Markdown escapes cells and link syntax.
- Preview never writes. Apply reads once, renders outside the metrics lease, then uses an exclusive publication staging directory with pinned ancestry. No second metrics lease. Existing generated filenames require the format's generator marker/schema identifier; unmarked files, symlinks, FIFOs and directories are refused and preserved.
- Recheck destination identity/content metadata immediately before publish. A new target uses exclusive publication; clean up only owned staging files. Concurrent apply and injected parent/target swaps preserve user/outside files and allow a later safe retry.
- A failed multi-file publication is reported as incomplete and never described as an atomic set. Each generated file carries the same report generation ID so mixed generations are detectable; readers see complete files. Input snapshots remain byte-identical.
- Guard tests include an in-memory mutant proving the ownership and ancestor-swap tests fail for the intended reason.

### S3 — state integration and contract

`node ai-framework/scripts/run-tests.mts --runtime node ai-framework/scripts/state-html.test.mts ai-framework/scripts/state-snapshot.test.mts ai-framework/scripts/flow-report.test.mts ai-framework/scripts/flow-render.test.mts` exits 0.

- Add the fixed flow-report.html link through state-pages' existing safe link helper. Existing report links remain. No target gives an unavailable line; unsafe target never becomes a link. Rendering /state never invokes or refreshes flow-report.
- Static HTML artifact checks exercise present, missing and unsafe report targets and existing page navigation/CSP. No app build/typecheck/lint exists; do not invent one.
- Contract documents commands, units, nulls, capture windows, pending timing, source refusal, bounds, ownership and partial publication recovery. No changes to the /state AI tokens slot or collector APIs.
- `node ai-framework/scripts/setup-validator.mts` and `node ai-framework/scripts/graphify.mts --check` exit 0. At final build/audit verification, `node ai-framework/scripts/run-tests.mts --runtime node` passes; `node ai-framework/scripts/run-tests.mts --runtime bun ai-framework/scripts/flow-join.test.mts ai-framework/scripts/flow-report.test.mts ai-framework/scripts/flow-render.test.mts ai-framework/scripts/state-html.test.mts` passes. Missing Bun is a prerequisite failure to resolve, not a waived check.
- VERSION and CHANGELOG are updated only during approved ship through the changelog skill/script against then-current release state; do not choose a version now.

## Impact analysis — acknowledgment required

**Risk: medium**, concentrated in read/publish path safety and truthful timing/coverage. No schema or collector changes. Six new files and five modified files include release metadata; workflow artifacts are administrative.

| Modified file | Downstream consumers | Checks / risk |
|---|---|---|
| state-pages.mts | state-render.mts directly; /state output and state-html tests indirectly | state-html.test.mts and state-snapshot.test.mts; additive link only |
| state-html.test.mts | Test runner discovery | Existing artifact and navigation coverage retained |
| integrations/workflow-metrics.md | Developers and receiving-project bundle sync | Contract must match commands and status semantics |
| VERSION / CHANGELOG.md | changelog tooling, workflow version reports, future release work | Serialize at ship; VERSION is not automatically synced to receiving projects |

Unchanged dependencies reused: workflow-metrics-state.mts (`metricsDirectory`, `readText`, `readWorkflowState`, `withMetricsLease`); runtime/entry.mts, runtime/cli.mts and RuntimeDeps. Their caller semantics remain unchanged. New report imports flow inward: CLI to pure join/render and existing runtime helpers. No barrel or API changes, external packages or boundary violations planned.

Knowledge alerts inherited: missing versus refused, directory identities across leases, generated-file ownership, prototype keys, output scrubbing, independent cap folds. The graph was queried before targeted consumer searches. No knowledge entries changed.

Cross-pitch: workflow-v3-rollout operates in receiving repositories; this plan neither edits those repositories nor chooses its base snapshot. Recheck release-file contention at audit/ship. OpenCode model pinning remains unsupported by the inspected runtime; use configured Claude alternate rather than retry that route.

## Risks

| Risk | Scope | Spike needed? | Mitigation |
|------|-------|---------------|------------|
| Private token reader cannot be imported | S1 | no; source checked | Reuse public byte reader; validate a minimal flow projection locally; no collector extraction |
| Stored intervals omit buffered time | S1 | no | Settled totals only, pending/buffered counts, explicit provisional status |
| Stale/truncated optional history | S1 | no | Independent guarded read and per-field unavailable states; no raw record parser |
| Two apply processes or ancestor swaps | S2 | no; injected tests required | Pinned exclusive staging, ownership check, publish reinspection, fail closed |
| Three output files are not an atomic set | S2 | no | Generation ID and explicit incomplete result; no false transaction claim |
| Appetite may grow with security cases | all | plan/build checkpoint | Target about 1,300 LOC; stop before 1,500 LOC/15 files; propose JSON report then presentation as separate pitches if needed |
| Sparse capture does not represent adoption | all | no | Synthetic boundary evidence plus labeled live smoke; no complete-coverage claim |

## Parallel dispatch plan

1. No implementation dispatch during planning. After plan approval and the big-batch build-start gate, inspect the bound Orca Run. The shape Run objective explicitly covers pre-bet review only; do not silently reuse it for implementation. Bind a suitable build Run under the coordinator protocol.
2. Dispatch S1 to configured Claude standard profile (`claude-sonnet-5-5`); collect its own worker_done, independently inspect diff and rerun exits. Do not include .project paths in implementation filesModified.
3. After S1 is settled, transfer its two CLI files to S2's worker. Dispatch S2 at standard profile; shared CLI ownership prohibits parallel execution.
4. Coordinator performs S3 after S2 evidence. There is no safe scope fan-out in this bounded plan. Mandatory audit fan-out occurs in /audit under its own skill.
5. Big-batch scope gates remain active; never auto-advance past a scope confirmation.

## Wireframe (static report, light)

```text
Flow report | generated timestamp | source status and observation windows
Coverage: tokens reported / completions | active ms | wait ms (lower bound)
Pitch > phase > scope rows | vendor tokens | attribution/overflow gaps
Pitch transition counts and bounded trace
History evidence | unavailable metrics and reasons | limits/provisional notes
```

```mermaid
stateDiagram-v2
    [*] --> Read
    Read --> Unavailable: missing or unsupported source
    Read --> Refused: unsafe path or lease failure
    Read --> Preview: sanitized report
    Unavailable --> Preview: report with reasons
    Preview --> [*]: default stdout only
    Preview --> Publish: explicit apply
    Publish --> Saved: all owned files published
    Publish --> Incomplete: refusal or partial publish
    Saved --> [*]
    Refused --> [*]
    Incomplete --> [*]
```

No UI framework, component skeleton, AI-prompt scope or golden model eval applies. Artifact/behavior tests cover this static report.

## Living-spec deviations log

S1/S2 dispositions are in deviations.md: usage reader bounds 52/18; explicit preview/apply modes and static-report UX exceptions. Actual S1+S2 size is 1,360 lines, whole-pitch projection 1,456. No appetite increase approved.

## Confirmation gate

Owner selected **Approve** on 2026-10-21. Plan finalized and impact acknowledged. The owner separately approved build start on 2026-10-21; S1 execution begins under Run `run_3de93fe9dd4a`.

## Test strategy carried from approved exits

This table organizes the already approved behavior checks; it does not replace them. Tests use Node test with RuntimeDeps injection and shared fixture helpers, not implementation snapshots.

| Source | Critical behavior / edge case | Type | Test file |
|---|---|---|---|
| flow-join.mts | Exact joins and nonadditive time; sentinel/overflow/partial data | Unit | flow-join.test.mts |
| flow-report.mts | Single guarded snapshot and no writes in preview; lease/path/input refusal | Integration | flow-report.test.mts |
| flow-render.mts | Equivalent sanitized semantics across formats; hostile labels and output cap | Unit/artifact | flow-render.test.mts |
| flow-report.mts publication | Owned files only; concurrent publish and directory/target swap | Integration with injected scheduling | flow-report.test.mts |
| state-pages.mts | Existing flow-report link only; missing/unsafe target and no generation | Artifact integration | state-html.test.mts |

Test-strategy coverage checks at scope completion: utilities target ≥90%; orchestration target ≥80%. Use run-tests.mts --coverage for the scoped Node tests and inspect per-file evidence; coverage is supplementary to the explicit behavior cases. No browser E2E, frontend build or framework render test is needed for this static report.

## Build verification rollup

S1, S2 and S3 are done with current-session evidence in S1-evidence.md, S2-evidence.md and S3-evidence.md. Final Node full suite: 2469 pass, 0 fail, 3 existing skips; scoped Node 207 and Bun 120 pass. The first full attempt's geometry timing failure and clean retry are retained in log.md. Implementation/test/contract count is 1427 changed lines across nine files; release metadata is reserved for ship. Await owner approval of the final scope and build-end gate before audit.


# Workflow usage metrics

The workflow usage collector records useful activity within one initialized project. It stores
session starts, primary/subagent finishes, skill use, phase and pitch activity, gate decisions,
audit outcomes and successful pitch completions (ships). Reports group these by vendor, pitch,
UTC day, provider/model, role, skill and phase. Missing attribution and collection limits remain
visible. Counts describe recorded events, not all work performed in the project.

## Record and report

Run these commands from the installed project's root. Node 22.18+ runs `.mts` directly; on
Node 22.12–22.17 add `--experimental-strip-types --disable-warning=ExperimentalWarning`.
You can also invoke the same script with Bun.

```sh
node ai-framework/scripts/workflow-metrics.mts record --root . <<'JSON'
{"eventId":"example-build-use-1","kind":"skill.used","vendor":"codex","source":"manual","pitch":"example-pitch","phase":"build","skill":"build"}
JSON
node ai-framework/scripts/workflow-metrics.mts report --root . --format markdown
```

Use a new event ID for each actual occurrence; the example is a manual record, not automatic
capture. `record` accepts one JSON object on stdin. `report` accepts `json`, `markdown` (default)
or `html`, emits the selected format on stdout and regenerates both local report views.
Generating reports never records usage or initializes an empty event snapshot.

All files live under the target project's Git-ignored `.project/metrics/`:

| File | Purpose |
|------|---------|
| `workflow-usage.json` | Schema 2 event aggregates, time and flow state, and bounded internal bookkeeping |
| `workflow-usage.dropped` | Transient: one byte per capture that could not take the lease, removed when the next event is recorded |
| `workflow-usage.md` | Generated readable report |
| `workflow-usage.html` | Generated static browser report, without scripts or external assets |

The workflow-only JSON report omits project UUIDs, replay hashes and pending activity identifiers.
Its generator neither imports nor modifies `token-consumption.*` files. Usage starts at the
first accepted event; there is no historical backfill. The state is schema 2. A file written by
an earlier version (`schemaVersion` 1) is migrated by editing the version token and appending the `usage` block on
the next recorded event. A report reads it in memory only and never rewrites it, and shows time
and flow as "not yet counting" until that migration.

## Event contract

Required fields are `eventId`, `kind`, nonempty `vendor`, and `source` (`manual`, `workflow` or
`native`). `occurredAt` defaults to collection time; supplied timestamps must be canonical UTC
ISO strings, such as `2026-10-08T12:00:00.000Z`, no more than five minutes in the future.

| Kind | Additional required fields | Meaning |
|------|----------------------------|---------|
| `session.started` | `sessionId` | One explicitly recorded session start |
| `agent.started`, `agent.finished` | `activityId`; finishes also need `outcome` | Agent lifecycle |
| `phase.started`, `phase.paused`, `phase.resumed`, `phase.finished` | `activityId`; finishes also need `outcome` | Phase lifecycle |
| `skill.used` | None | One declared skill use |
| `gate.decided` | `decision` | One explicit gate decision |
| `pitch.started`, `pitch.finished` | Finishes need `outcome` | Pitch lifecycle; completed finish counts as a ship |
| `audit.finished` | `outcome` | One audit cycle |

Outcomes are `completed`, `failed` or `cancelled`; decisions are `approve`, `revise`, `back` or
`stop`. Optional labels are `pitch`, `phase`, `skill`, `provider`, `model`, `role` and
`workflowVersion`, plus `scope`, which is absent (shown as `(none)`) or a short label such as `S3`
(`S` and one to three digits); any other scope is stored as overflow and never matches.
`agentKind` is `primary`, `subagent` or `unknown`. An audit may supply integer `mustFixCount` from
zero through 1,000,000.

A start and its finish are matched by event family (agent or phase), vendor, `sessionId` and `activityId` only.
Labels are fixed at the start: a finish is attributed to the pitch and phase of its start.
A phase change in the middle of a turn therefore never moves the interval. A finish with no matching start is counted as unmatched
and adds no duration. Invalid vendor, pitch, phase or scope labels prevent matching; their events
still count, but finishes remain unmatched. A second start for the same primary turn replaces the
open one without a duration (counted as a superseded turn); a second start for a phase or
subagent is refused as already started. Combined provider/model labels exceeding 80 characters enter the
overflow bucket and count as model-attribution gaps.

Opaque event/session/activity identifiers have a maximum length of 128 characters. Labels
have a maximum of 80 ASCII identifier characters (letters, digits, `_ . : / @ + -`); invalid
labels enter an explicit overflow bucket and absent labels enter an unknown bucket. Unknown
input fields are discarded. No tokens, cost, savings, execution estimates, prompts, transcripts
or raw hook payloads are stored. Library callers use `recordWorkflowEvent(input, root, deps)`
from `workflow-metrics-state.mts`, with injected `RuntimeDeps`.

## Reading the evidence

Agent finishes, session starts, skills, phase finishes, audits and ships have separate units.
Combined terminal outcomes count finish events across agents, phases, pitches and audits;
they are not unique tasks. Unknown model/role attribution appears as gaps rather than ranked
entries. A successful phase does not imply a shipped pitch. Early snapshots without the ship
counter show unavailable historical ships when prior pitch finishes cannot be reconstructed.

Elapsed time exists only for matching agent/phase starts and finishes. It includes pauses and
human wait. Summed intervals may overlap, so they are not active work time or productivity.
Pending, paused, unmatched and evicted activity counts explain incomplete evidence.

### Time and flow

The `usage` block adds two measures that are exact unions, not sums:

- **Active time** is the measure of the union of matched agent intervals: primary turns and
  subagents. Phase segments are not active time, because they span the gaps between turns; they
  keep only their `elapsedMs`.
- **Wait time** is elapsed between turns, not necessarily think-time. In one session it runs from
  a completed primary finish to that session's next primary start, capped at eight hours (time
  over the cap counts in `gapsOverCap`). Only the part not covered by active time at the same level
  counts, so a subagent running inside a gap reduces the wait by exactly that part.

Each interval or measured gap is credited to the total, its pitch, its pitch and phase, and its
pitch, phase and scope. Counters are `turnsStarted`, `turnsFinished`, `gapsMeasured`,
`gapsUnmeasured` and `gapsOverCap`. A gap is unmeasured when the clock sources differ (the
collector clock against a caller-supplied time), when the next prompt is earlier than the Stop, when
a turn was still open, or when its session was evicted. A cancelled or failed finish opens no gap.
An agent interval whose start and finish use different clocks keeps its `elapsedMs` but adds no
active time (`mixedClockIntervals`).

Time is folded as soon as nothing pending can overlap it. Closed intervals wait in a bounded list
until then. If the list fills, the fold is forced forward and the lost part is counted as clipped
(`clippedIntervals`), so active and wait stay a lower bound and are never inflated. Dropped
captures that never reached the lease are counted from the marker file the same way: a lower
bound, because the marker holds at most 4,096 bytes.

Phase order is recorded per pitch without any text: each phase start is classified against the
previous one as `repeat`, `forward`, `back` or `other` by the pipeline order (shape, critique,
plan, build, audit, ship), with the newest 32 starts kept as a short trace. No gate decision is
inferred from it.

### Hook-to-event mapping (planned)

Written by `workflow-usage-capture`; not wired by this core. The state accepts these events from
any caller today.

| Hook | Event | Notes |
|------|-------|-------|
| `SessionStart` | `session.started` | Opens a session |
| `UserPromptSubmit` | `agent.started`, `agentKind: primary` | One turn; never a completion |
| `Stop` | `agent.finished`, `outcome: completed` | Closes the turn and opens a wait gap |
| `SubagentStop` | `agent.finished`, `agentKind: subagent` | Matches an earlier subagent start |
| `SessionEnd` | `agent.finished`, `outcome: cancelled` | Closes an open turn without a gap |
| Phase start | `phase.started` | Carries the pitch, phase and scope labels |

Native capture uses `segment:<sessionId>` as the phase activity identity. A new native phase start on that identity
closes the previous segment as completed and opens its replacement in the same leased write. The derived phase
finish has a deterministic identifier, credits the old segment's labels and elapsed time, and never counts an
agent completion or active time. Replaying the incoming event does not repeat the close; a start earlier than the
open segment's last event is refused. Manual phase lifecycles retain their existing explicit finish requirement.

A native agent start with no pitch, phase or scope inherits those labels from its vendor/session's canonical open
segment. Explicit labels take precedence. A turn submitted before phase expansion retains the preceding segment's
labels; an initial turn without a segment stays unknown. Finishes preserve their start's labels, including scope,
when the phase changes mid-turn. The resolver's `(unattributed)` pitch and `(none)` scope are accepted explicitly;
arbitrary parenthesized labels still fold into the non-matchable other bucket. These are extensions of the accepted
values within schema 2; no persisted fields or lease behavior change.

Collection is `observed`, `stale` (more than seven days since the last recorded event) or
`unavailable`. Staleness does not prove collection failure. Automatic capture is computed from the
last event whose source was declared `native`: `unconfigured` when there is none, `observed` within
seven days, `stale` after that. Source labels are caller declarations; even a `native` event does
not verify an adapter, and this core wires no capture. Native hook migration, `/state` adoption and rollout into other projects are separate
work. Installed workflow version uses guarded `.project/.bundle-sync.json` source-version
evidence; root `VERSION` is only an explicitly unverified fallback. A first event creates a
local project UUID and safe display label; copying metrics into another project retains that
identity and is not a supported way to begin independent collection.

## Bounds and failures

The collector retains 512 recent event keys/fingerprints, 30 UTC daily buckets, 50 named
pitches, eight named vendors, 32 named labels per vendor/dimension, and 64 pending activities.
Time and flow add: 16 phases per pitch, 25 scopes per phase and 600 scope rows in total (extra
phases and scopes go to an overflow row), 32 sessions, a trace of 32 phase starts per pitch, and
256 closed intervals awaiting a fold. The least recently used pitch folds into the overflow pitch
when a 51st arrives, in both stores at once, unless a pending activity, open interval or session
still points to it; a fold is counted as `pitchFolds`, not as overflow. A pending agent activity
older than six hours is evicted (`pendingEvictions`); phase activities are evicted only by the
pending cap, oldest start first. The state, with every cap full, measures about 1 MB.
Overflow preserves aggregate totals; older events affect lifetime totals without evicting newer
days. Replay protection applies only inside the recent-key window; older replays can count again.
Input is capped at 16 KiB and each snapshot/report at 4 MiB. There is no raw event journal.

Writers share the existing loopback metrics lease and respect `.token-consumption.lock`.
Directory identities are pinned before lease acquisition and rechecked before filesystem
effects; ancestor replacement during the asynchronous wait is refused. Concurrent first
writers accept an existing directory only after checking that it is safe.
Unsafe directories, symlinks, non-regular files, corrupt or unsupported snapshots are refused
without reset or replacement. Writes use exclusive temporary files and atomic rename. Both
report destinations are checked first, but the two report writes are not one atomic transaction:
a failure may leave views from different generations. Source and generation timestamps identify
them; regenerate reports after resolving the failure. Report failures preserve event state.

Manual failures and duplicate records exit nonzero with fixed messages. `--best-effort` returns
zero for observational callers while still printing the skip/failure; inspect the receipt instead
of treating exit zero as evidence that an event was saved. No automatic repair or deletion occurs.

See also: [legacy token collector](../docs/token-consumption.md).

## Joined token/time report

`flow-report.mts` reads token schema 3 and usage schema 2 under one shared metrics lease.
It never records events, rewrites snapshots or reads transcripts. Rendering and publication happen
after releasing that lease; the optional `.project/reports/state.json` history is read separately.

```sh
node ai-framework/scripts/flow-report.mts --root .
node ai-framework/scripts/flow-report.mts --root . --format markdown
node ai-framework/scripts/flow-report.mts --root . --format html
node ai-framework/scripts/flow-report.mts --root . --apply
```

Default output is JSON on stdout. Preview creates no files or directories. `--apply` publishes all
three fixed `.project/metrics/flow-report.{json,md,html}` files and prints a publication summary;
it cannot be combined with `--format`. `/state` links the existing HTML only when its path is safe;
it never generates or refreshes this report. Node compatibility flags and Bun support match the commands above.

Rows join exact canonical pitch/phase/scope keys, including `(none)` for no scope. Unknown,
unattributed, overflow and noncanonical keys remain separate per source. One-sided rows, independent
store folds, omitted rows, capture health and unmatched/unjoinable counts stay visible. Token rollups
sum disjoint leaves once; timing uses stored union rows, never child sums or vendor copies.

Tokens are vendor-reported flow totals with completion/reporting coverage, not a normalized work unit.
Unreported tokens are null; partial reporting shows its known sum and coverage. Active and wait values
are settled milliseconds. Wait is a lower bound of elapsed time between turns, not necessarily
think-time; pending/buffered intervals make timing provisional without extrapolation. Sources show
their separate observation windows and freshness (stale after seven days). Effort, cache/output-input
ratios and time-efficiency metrics are unavailable because flow fields or comparable windows are absent.

History reuses schema-1 `state.json` facts by exact slug, preserving audit/revision availability and
stale/truncated evidence. Missing history is unavailable; no audit/pitch records are reparsed and no
history is backfilled. Missing, refused and unsupported sources have distinct fixed reasons, not zeros.
Each input and output is capped at 4 MiB. Token projection allows 51 pitch buckets, 16 phases, 26
scopes and 600 vendor leaves; usage respects its reader's 52/18 overflow-inclusive limits. Output
keeps 100 leaf rows plus ancestors in stable order, with omitted counts and separate full/displayed totals.

All formats carry an explicit generator marker and the same generation ID. HTML is standalone,
script-free and CSP-protected; wide tables have keyboard-focusable scroll regions. Apply preserves
unmarked files, symlinks and non-files. It uses exclusive staging, pinned directory identities,
destination reinspection and exclusive creation or verified replacement; cleanup touches only its files.
Publication is one file at a time, not an atomic set. Interrupted writes exit nonzero and identify known
published files; compare generation IDs and rerun after resolving the cause. A changed/foreign staging
directory is preserved. If `.flow-report.staging` remains, first establish that no apply is running and
inspect its ownership before removing it; the tool never deletes an unknown stage automatically.
Path-based operations still have a check-to-syscall race; these guards do not claim anchored OS isolation.

Successful previews (including unavailable-source reports) and complete applies exit 0; unsafe paths,
lease failures or refused/incomplete publication exit 1; invalid options exit 2. Errors do not echo raw
source values. No token, cost, productivity or historical savings estimates are generated.
